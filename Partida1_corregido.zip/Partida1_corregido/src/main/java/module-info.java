module poli.edu.co {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;
    requires java.sql;

    // La vista (App.java) necesita abrirse a JavaFX para el lanzamiento
    opens poli.edu.co.vista       to javafx.fxml, javafx.graphics;
    opens poli.edu.co.controlador to javafx.fxml;
    opens poli.edu.co.modelo      to javafx.fxml;

    exports poli.edu.co.vista;
    exports poli.edu.co.modelo;
    exports poli.edu.co.modelo.dao;
    exports poli.edu.co.controlador;
}
