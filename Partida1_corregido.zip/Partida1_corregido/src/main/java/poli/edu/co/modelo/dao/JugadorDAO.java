package poli.edu.co.modelo.dao;

import poli.edu.co.modelo.Jugador;
import java.util.List;

/**
 * Contrato de acceso a datos para la entidad Jugador.
 *
 * Siguiendo el patrón del ejemplo del profesor (interfaz CRUD genérica),
 * esta interfaz define las operaciones que cualquier implementación debe ofrecer.
 * Permite cambiar la implementación (MySQL, SQLite, H2…) sin modificar el resto del código.
 */
public interface JugadorDAO {

    /** Persiste un jugador y rellena su id generado. */
    void guardar(Jugador jugador);

    /** Devuelve los 10 mejores puntajes en orden descendente. */
    List<Jugador> obtenerTop10();
}
