package poli.edu.co.modelo;

import java.util.Random;

/**
 * Representa una sesión de juego activa.
 *
 * Esta clase consolida lo que antes estaba repartido entre Partida y JuegoModelo:
 * toda la lógica de estado de la partida (modo, intentos, reto) vive aquí.
 * JuegoModelo actúa como fachada que coordina Partida con el DAO, sin duplicar lógica.
 *
 * La regla matemática se delega directamente al Nivel, eliminando la clase
 * Regla que era redundante (Nivel ya encapsula expresión + aplicar + verificar).
 */
public class Partida {

    public static final int MAX_INTENTOS = 3;
    private static final Random RANDOM = new Random();

    // ── Estado ────────────────────────────────────────────────────────────────
    private final Nivel nivel;
    private boolean     modoValidacion;
    private boolean     terminada;
    private boolean     ganada;
    private int         intentosRestantes;

    // ── Reto de validación ────────────────────────────────────────────────────
    private final int[] entradasReto;
    private boolean     retoGenerado;

    public Partida(Nivel nivel) {
        this.nivel             = nivel;
        this.modoValidacion    = false;
        this.terminada         = false;
        this.ganada            = false;
        this.intentosRestantes = MAX_INTENTOS;
        this.entradasReto      = new int[4];
        this.retoGenerado      = false;
    }

    // ── Lógica de juego ───────────────────────────────────────────────────────

    /** Aplica la regla del nivel al número dado (Fase 1: exploración). */
    public int aplicarRegla(int x) {
        return nivel.aplicar(x);
    }

    /** Pasa al modo validación y genera el reto de 4 números (solo la primera vez). */
    public void iniciarModoValidacion() {
        modoValidacion = true;
        if (!retoGenerado) {
            for (int i = 0; i < 4; i++) {
                entradasReto[i] = RANDOM.nextInt(9) + 1;
            }
            retoGenerado = true;
        }
    }

    /** Regresa al modo exploración sin reiniciar los intentos. */
    public void volverExploracion() {
        modoValidacion = false;
    }

    /** Verifica si el texto escrito por el jugador coincide con la expresión del nivel. */
    public boolean verificarExpresion(String texto) {
        return nivel.verificarExpresion(texto);
    }

    /** Verifica si las 4 salidas ingresadas por el jugador son correctas. */
    public boolean verificarSalidas(int[] respuestas) {
        for (int i = 0; i < 4; i++) {
            if (respuestas[i] != nivel.aplicar(entradasReto[i])) return false;
        }
        return true;
    }

    /**
     * Registra un intento fallido y marca la partida como terminada si se agotaron.
     *
     * @return true si el jugador perdió (intentos agotados), false si aún quedan intentos.
     */
    public boolean registrarIntentoFallido() {
        intentosRestantes--;
        if (intentosRestantes <= 0) {
            terminada = true;
            return true;
        }
        return false;
    }

    /** Marca la partida como ganada y terminada. */
    public void ganar() {
        terminada = true;
        ganada    = true;
    }

    // ── Getters ───────────────────────────────────────────────────────────────
    public Nivel   getNivel()              { return nivel; }
    public String  getExpresionRegla()    { return nivel.getExpresion(); }
    public boolean isModoValidacion()     { return modoValidacion; }
    public boolean isTerminada()          { return terminada; }
    public boolean isGanada()             { return ganada; }
    public int     getIntentosRestantes() { return intentosRestantes; }
    public int[]   getEntradasReto()      { return entradasReto; }
}
