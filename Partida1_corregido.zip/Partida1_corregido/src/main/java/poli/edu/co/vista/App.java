package poli.edu.co.vista;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import poli.edu.co.modelo.JuegoModelo;
import poli.edu.co.modelo.dao.ConexionBD;

import java.io.IOException;

/**
 * Punto de entrada de la aplicación JavaFX (capa Vista en MVC).
 *
 * Responsabilidades:
 *  1. Inicializar la base de datos (crear tablas si no existen).
 *  2. Crear el modelo compartido y exponerlo a los controladores.
 *  3. Gestionar la navegación entre pantallas (setRoot).
 *
 * Los controladores acceden al modelo mediante App.getModelo(),
 * nunca lo instancian por su cuenta.
 */
public class App extends Application {

    private static JuegoModelo modelo;
    private static Scene       scene;

    @Override
    public void start(Stage stage) throws IOException {
        ConexionBD.inicializarTablas();   // crea la tabla si no existe
        modelo = new JuegoModelo();
        scene  = new Scene(loadFXML("primary"), 660, 520);
        stage.setTitle("Adivina la Regla");
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }

    /** El modelo es compartido: todos los controladores usan la misma instancia. */
    public static JuegoModelo getModelo() { return modelo; }

    /** Navega a otra pantalla reemplazando la raíz de la escena. */
    public static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader loader = new FXMLLoader(
            App.class.getResource("/poli/edu/co/" + fxml + ".fxml"));
        return loader.load();
    }

    public static void main(String[] args) {
        launch();
    }
}
