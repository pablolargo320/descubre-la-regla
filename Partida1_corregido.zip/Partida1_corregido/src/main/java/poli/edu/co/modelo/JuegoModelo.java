package poli.edu.co.modelo;

import poli.edu.co.modelo.dao.JugadorDAO;
import poli.edu.co.modelo.dao.JugadorDAOImpl;

import java.util.Random;

/**
 * Fachada principal del juego (capa de Modelo en MVC).
 *
 * Coordina la Partida activa, calcula el Puntaje y delega la persistencia
 * del Jugador al DAO correspondiente. Los controladores solo interactúan
 * con esta clase: nunca acceden a la base de datos ni instancian DAOs directamente.
 *
 * Mensajes de estado (mensajeExploracion, mensajeValidacion, ultimaSalida)
 * se preparan aquí para que la vista solo los lea y los muestre, sin formatearlos.
 */
public class JuegoModelo {

    private static final Random RANDOM = new Random();

    // ── Estado de la sesión ───────────────────────────────────────────────────
    private Partida partida;
    private Nivel   nivelActual;
    private Puntaje puntaje = Puntaje.cero();

    // ── Mensajes para la vista ────────────────────────────────────────────────
    private String mensajeExploracion;
    private String mensajeValidacion;
    private String ultimaSalida;

    // ── Acceso a datos (inyectado por la interfaz, no por la implementación) ──
    private final JugadorDAO jugadorDAO = new JugadorDAOImpl();

    public JuegoModelo() {
        iniciarPartidaAleatoria();
    }

    // ── Ciclo de vida ─────────────────────────────────────────────────────────

    /** Inicia una partida con el nivel elegido por el jugador desde la UI. */
    public void setNivel(Nivel nivel) {
        nivelActual  = nivel;
        partida      = new Partida(nivel);
        puntaje      = Puntaje.cero();
        ultimaSalida = "";
        resetMensajes();
    }

    /** Nueva partida con nivel aleatorio (usada al iniciar la app). */
    public void reiniciar() {
        iniciarPartidaAleatoria();
        ultimaSalida = "";
        puntaje      = Puntaje.cero();
    }

    private void iniciarPartidaAleatoria() {
        Nivel[] niveles = Nivel.values();
        nivelActual = niveles[RANDOM.nextInt(niveles.length)];
        partida     = new Partida(nivelActual);
        resetMensajes();
    }

    private void resetMensajes() {
        mensajeExploracion = "Ingresa números enteros y observa la salida del sistema.";
        mensajeValidacion  = "";
    }

    // ── Lógica de juego (delega a Partida) ────────────────────────────────────

    public int aplicarRegla(int x) {
        return partida.aplicarRegla(x);
    }

    public void iniciarModoValidacion() {
        partida.iniciarModoValidacion();
        mensajeValidacion = "Da las 4 salidas correctas. Intentos restantes: "
                + partida.getIntentosRestantes();
    }

    public void volverExploracion() {
        partida.volverExploracion();
        mensajeValidacion  = "";
        mensajeExploracion = "Ingresa números enteros y observa la salida del sistema.";
    }

    public boolean verificarTextoRegla(String texto) {
        return partida.verificarExpresion(texto);
    }

    public boolean verificarSalidas(int[] respuestas) {
        return partida.verificarSalidas(respuestas);
    }

    /** Registra un intento fallido y actualiza mensajes. */
    public void registrarIntentoFallido() {
        boolean perdio = partida.registrarIntentoFallido();
        if (perdio) {
            puntaje           = Puntaje.cero();
            mensajeValidacion = "Perdiste. La regla era: " + partida.getExpresionRegla();
        } else {
            mensajeValidacion = "Incorrecto. Intentos restantes: " + partida.getIntentosRestantes();
        }
    }

    /** Marca la victoria y calcula el puntaje final. */
    public void ganar() {
        partida.ganar();
        puntaje           = Puntaje.calcular(partida.getIntentosRestantes(), true);
        mensajeValidacion = "¡Correcto! Descubriste la regla: " + partida.getExpresionRegla();
    }

    // ── Registro del jugador (delega al DAO) ──────────────────────────────────

    /**
     * Crea un Jugador con el nombre dado y lo persiste vía DAO.
     * El controlador nunca instancia Jugador ni llama al DAO: eso es responsabilidad del modelo.
     *
     * @throws IllegalArgumentException si el nombre es nulo o vacío.
     * @throws RuntimeException         si ocurre un error de persistencia.
     */
    public void guardarJugador(String nombre) {
        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("El nombre del jugador no puede estar vacío.");
        }
        Jugador jugador = new Jugador(nombre.trim(), puntaje.getValor());
        jugadorDAO.guardar(jugador);
    }

    // ── Getters ───────────────────────────────────────────────────────────────
    public boolean isModoValidacion()      { return partida.isModoValidacion(); }
    public boolean isTerminado()           { return partida.isTerminada(); }
    public boolean isUltimaPartidaGanada() { return partida.isGanada(); }
    public int     getIntentosRestantes()  { return partida.getIntentosRestantes(); }
    public int[]   getEntradasReto()       { return partida.getEntradasReto(); }
    public Nivel   getNivelActual()        { return nivelActual; }
    public Puntaje getPuntaje()            { return puntaje; }

    public String getMensajeExploracion()  { return mensajeExploracion; }
    public String getMensajeValidacion()   { return mensajeValidacion; }
    public String getUltimaSalida()        { return ultimaSalida; }

    public void setUltimaSalida(String salida) { this.ultimaSalida = salida; }
}
