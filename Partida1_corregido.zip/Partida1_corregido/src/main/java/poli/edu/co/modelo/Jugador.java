package poli.edu.co.modelo;

/**
 * Entidad que representa a un jugador y su resultado en una partida.
 * Solo contiene datos (nombre y puntaje): no tiene lógica de negocio
 * ni acceso a base de datos.
 */
public class Jugador {

    private int          id;
    private final String nombre;
    private final int    puntaje;

    public Jugador(String nombre, int puntaje) {
        this.nombre  = nombre;
        this.puntaje = puntaje;
    }

    // ── Getters / Setters ─────────────────────────────────────────────────────
    public int    getId()      { return id; }
    public String getNombre()  { return nombre; }
    public int    getPuntaje() { return puntaje; }

    public void setId(int id)  { this.id = id; }

    @Override
    public String toString() {
        return nombre + " — " + puntaje + " pts";
    }
}
