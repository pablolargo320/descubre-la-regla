package poli.edu.co.controlador;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import poli.edu.co.modelo.JuegoModelo;
import poli.edu.co.vista.App;

import java.io.IOException;

/**
 * Controlador de la pantalla de resultado.
 *
 * Muestra puntaje y nivel, solicita el nombre del jugador y gestiona el guardado.
 * No contiene lógica de negocio: delega todo a JuegoModelo.
 * No accede a la base de datos directamente: eso es responsabilidad del DAO,
 * al que JuegoModelo llama internamente.
 */
public class ResultadoControlador {

    // ── Vista ─────────────────────────────────────────────────────────────────
    @FXML private Label     resultadoLabel;
    @FXML private Label     nivelLabel;
    @FXML private Label     puntajeLabel;

    @FXML private TextField nombreField;
    @FXML private Label     errorNombreLabel;
    @FXML private Button    btnGuardar;
    @FXML private Label     confirmacionLabel;

    private JuegoModelo modelo;

    // ── Inicialización ────────────────────────────────────────────────────────

    @FXML
    private void initialize() {
        modelo = App.getModelo();
        mostrarResultado();
    }

    // ── Sincronización de vista ───────────────────────────────────────────────

    private void mostrarResultado() {
        boolean gano = modelo.isUltimaPartidaGanada();

        if (gano) {
            resultadoLabel.setText("¡GANASTE!");
            resultadoLabel.setStyle(
                "-fx-text-fill: #4caf50; -fx-font-size: 28px; -fx-font-weight: bold;");
        } else {
            resultadoLabel.setText("PERDISTE");
            resultadoLabel.setStyle(
                "-fx-text-fill: #ef5350; -fx-font-size: 28px; -fx-font-weight: bold;");
        }

        nivelLabel.setText("Nivel jugado: " + modelo.getNivelActual().name());
        puntajeLabel.setText("Puntaje: " + modelo.getPuntaje());

        errorNombreLabel.setVisible(false);
        errorNombreLabel.setManaged(false);
        confirmacionLabel.setVisible(false);
        confirmacionLabel.setManaged(false);
    }

    // ── Eventos ───────────────────────────────────────────────────────────────

    /**
     * Valida el nombre e intenta guardar el puntaje vía modelo.
     * El controlador nunca accede al DAO ni instancia Jugador directamente.
     */
    @FXML
    private void guardar() {
        String nombre = nombreField.getText().trim();

        if (nombre.isBlank()) {
            errorNombreLabel.setText("Debe ingresar un nombre");
            errorNombreLabel.setVisible(true);
            errorNombreLabel.setManaged(true);
            return;
        }

        errorNombreLabel.setVisible(false);
        errorNombreLabel.setManaged(false);

        try {
            modelo.guardarJugador(nombre);   // el modelo crea el Jugador y llama al DAO
            confirmacionLabel.setVisible(true);
            confirmacionLabel.setManaged(true);
            btnGuardar.setDisable(true);     // evitar doble guardado
            nombreField.setDisable(true);
        } catch (RuntimeException e) {
            errorNombreLabel.setText("Error al guardar. Intente de nuevo.");
            errorNombreLabel.setVisible(true);
            errorNombreLabel.setManaged(true);
        }
    }

    @FXML
    private void nuevaPartida() throws IOException {
        App.setRoot("Nivel");
    }

    @FXML
    private void volverMenu() throws IOException {
        App.setRoot("primary");
    }
}
