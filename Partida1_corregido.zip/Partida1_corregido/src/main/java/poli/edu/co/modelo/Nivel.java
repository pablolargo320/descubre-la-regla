package poli.edu.co.modelo;

/**
 * Define los niveles de dificultad del juego y la regla matemática asociada a cada uno.
 * Cada constante implementa el método aplicar(), lo que evita tener
 * una clase Regla separada y elimina la redundancia detectada por el profesor.
 */
public enum Nivel {

    FACIL("x*2") {
        @Override
        public int aplicar(int x) { return x * 2; }
    },
    INTERMEDIO("x+5") {
        @Override
        public int aplicar(int x) { return x + 5; }
    },
    DIFICIL("x*3") {
        @Override
        public int aplicar(int x) { return x * 3; }
    };

    private final String expresion;

    Nivel(String expresion) {
        this.expresion = expresion;
    }

    /** Aplica la regla matemática del nivel al número dado. */
    public abstract int aplicar(int x);

    /** Expresión legible de la regla (ej: "x*2"). */
    public String getExpresion() { return expresion; }

    /** Verifica si el texto ingresado por el usuario coincide con la expresión del nivel. */
    public boolean verificarExpresion(String texto) {
        if (texto == null || texto.isBlank()) return false;
        return texto.replace(" ", "").toLowerCase().equals(expresion);
    }
}
