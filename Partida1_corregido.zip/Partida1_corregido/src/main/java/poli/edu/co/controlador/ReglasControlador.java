package poli.edu.co.controlador;

import java.io.IOException;
import javafx.fxml.FXML;
import poli.edu.co.vista.App;

/**
 * Controlador de la pantalla de reglas del juego.
 * Solo gestiona la navegación.
 */
public class ReglasControlador {

    @FXML
    private void volverMenu() throws IOException {
        App.setRoot("primary");
    }
}
