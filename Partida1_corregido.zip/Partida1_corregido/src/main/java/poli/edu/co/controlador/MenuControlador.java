package poli.edu.co.controlador;

import java.io.IOException;
import javafx.fxml.FXML;
import poli.edu.co.vista.App;

/**
 * Controlador del menú principal.
 * Solo gestiona la navegación; no contiene lógica de negocio.
 */
public class MenuControlador {

    @FXML
    private void iniciarPartida() throws IOException {
        App.setRoot("Nivel");
    }

    @FXML
    private void abrirReglas() throws IOException {
        App.setRoot("secondary");
    }
}
