package poli.edu.co.controlador;

import javafx.fxml.FXML;
import java.io.IOException;
import poli.edu.co.modelo.Nivel;
import poli.edu.co.vista.App;

/**
 * Controlador de la pantalla de selección de nivel.
 * Delega la configuración del nivel al modelo; no contiene lógica de negocio.
 */
public class NivelControlador {

    @FXML
    private void seleccionarFacil() throws IOException {
        seleccionar(Nivel.FACIL);
    }

    @FXML
    private void seleccionarIntermedio() throws IOException {
        seleccionar(Nivel.INTERMEDIO);
    }

    @FXML
    private void seleccionarDificil() throws IOException {
        seleccionar(Nivel.DIFICIL);
    }

    @FXML
    private void volverMenu() throws IOException {
        App.setRoot("primary");
    }

    private void seleccionar(Nivel nivel) throws IOException {
        App.getModelo().setNivel(nivel);   // el modelo decide qué Partida crear
        App.setRoot("Juego");
    }
}
