package poli.edu.co.modelo.dao;

import poli.edu.co.modelo.Jugador;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementación MySQL de JugadorDAO.
 *
 * Obtiene la conexión exclusivamente a través de ConexionBD.getInstancia().getConexion(),
 * tal como lo establece el patrón Singleton del ejemplo del profesor.
 */
public class JugadorDAOImpl implements JugadorDAO {

    @Override
    public void guardar(Jugador jugador) {
        String sql = """
                INSERT INTO jugadores (nombre, puntaje)
                VALUES (?, ?)
                """;

        try {
            Connection conn = ConexionBD.getInstancia().getConexion();
            PreparedStatement ps =
                    conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            ps.setString(1, jugador.getNombre());
            ps.setInt(2, jugador.getPuntaje());

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    jugador.setId(keys.getInt(1));
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException(
                    "Error al guardar el jugador: " + e.getMessage(), e);
        }
    }

    @Override
    public List<Jugador> obtenerTop10() {
        String sql =
                "SELECT id, nombre, puntaje " +
                "FROM jugadores " +
                "ORDER BY puntaje DESC " +
                "LIMIT 10";

        List<Jugador> lista = new ArrayList<>();

        try {
            Connection conn = ConexionBD.getInstancia().getConexion();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Jugador j = new Jugador(
                        rs.getString("nombre"),
                        rs.getInt("puntaje"),
                        "DESCONOCIDO"
                );

                j.setId(rs.getInt("id"));
                lista.add(j);
            }

        } catch (SQLException e) {
            throw new RuntimeException(
                    "Error al consultar jugadores: " + e.getMessage(), e);
        }

        return lista;
    }
}