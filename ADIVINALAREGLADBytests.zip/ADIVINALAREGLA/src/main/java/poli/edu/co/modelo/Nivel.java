package poli.edu.co.modelo;

/**
 * Enum que representa los niveles del juego.
 * Cada nivel define una regla matemática diferente.
 */
public enum Nivel {

    FACIL {
        @Override
        public int aplicar(int x) {
            return x * 2;
        }

        @Override
        public String getExpresion() {
            return "x*2";
        }
    },

    INTERMEDIO {
        @Override
        public int aplicar(int x) {
            return x + 5;
        }

        @Override
        public String getExpresion() {
            return "x+5";
        }
    },

    DIFICIL {
        @Override
        public int aplicar(int x) {
            return x * 3;
        }

        @Override
        public String getExpresion() {
            return "x*3";
        }
    };

    /**
     * Aplica la regla matemática al valor dado.
     */
    public abstract int aplicar(int x);

    /**
     * Retorna la expresión textual de la regla.
     */
    public abstract String getExpresion();

    /**
     * Verifica si el texto ingresado coincide con la expresión del nivel.
     * Ignora espacios y mayúsculas/minúsculas.
     */
    public boolean verificarExpresion(String texto) {
        if (texto == null || texto.trim().isEmpty()) {
            return false;
        }

        String entrada = texto.replaceAll("\\s+", "").toLowerCase();
        String correcta = getExpresion().replaceAll("\\s+", "").toLowerCase();

        return entrada.equals(correcta);
    }
}
