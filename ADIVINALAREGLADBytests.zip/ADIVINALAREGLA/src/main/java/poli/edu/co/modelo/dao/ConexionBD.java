package poli.edu.co.modelo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Gestiona la conexión con la base de datos mediante el patrón Singleton.
 *
 * La conexión se obtiene una sola vez y se reutiliza en toda la aplicación.
 * Si la conexión se cierra o es nula, se reabre automáticamente.
 *
 * ⚠️ Ajusta HOST, PORT, DB, USER y PASSWORD según tu configuración local.
 *    Por defecto XAMPP usa: host=localhost, puerto=3306, usuario=root, sin contraseña.
 */
public final class ConexionBD {

    // ── Parámetros de conexión ────────────────────────────────────────────────
    private static final String HOST     = "localhost";
    private static final int    PORT     = 3306;
    private static final String DB       = "adivina_regla";
    private static final String USER     = "root";
    private static final String PASSWORD = "";   // XAMPP no tiene contraseña por defecto

    private static final String URL =
            "jdbc:mysql://" + HOST + ":" + PORT + "/" + DB
            + "?useSSL=false&serverTimezone=America/Bogota&allowPublicKeyRetrieval=true";

    // ── Singleton ─────────────────────────────────────────────────────────────
    private static ConexionBD instancia;
    private Connection conexion;

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new ExceptionInInitializerError(
                "Driver MySQL no encontrado en el classpath: " + e.getMessage());
        }
    }

    private ConexionBD() throws SQLException {
        conexion = DriverManager.getConnection(URL, USER, PASSWORD);
    }

    /**
     * Devuelve la única instancia de ConexionBD.
     * Si no existe o está cerrada, la crea de nuevo.
     */
    public static ConexionBD getInstancia() throws SQLException {
        if (instancia == null) {
            instancia = new ConexionBD();
        }
        return instancia;
    }

    /**
     * Devuelve la conexión activa.
     * Si la conexión está cerrada, la reabre automáticamente.
     */
    public Connection getConexion() throws SQLException {
        if (conexion == null || conexion.isClosed()) {
            instancia = new ConexionBD();
            return instancia.conexion;
        }
        return conexion;
    }

    /**
     * Crea la tabla 'jugadores' si no existe.
     * Se llama una sola vez al arrancar la aplicación (desde App.java).
     */
    public static void inicializarTablas() {
        String sql = """
                CREATE TABLE IF NOT EXISTS jugadores (
                    id      INT          NOT NULL AUTO_INCREMENT,
                    nombre  VARCHAR(100) NOT NULL,
                    puntaje INT          NOT NULL,
                    PRIMARY KEY (id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                """;
        try (Connection conn = getInstancia().getConexion();
             Statement  stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            throw new RuntimeException("Error al inicializar la base de datos: " + e.getMessage(), e);
        }
    }
}
