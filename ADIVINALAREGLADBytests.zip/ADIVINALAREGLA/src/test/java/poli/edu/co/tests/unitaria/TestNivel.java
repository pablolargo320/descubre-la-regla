package poli.edu.co.tests.unitaria;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import poli.edu.co.modelo.Nivel;

/**
 * Tests unitarios para el enum Nivel.
 */
public class TestNivel {

    @Test
    void facil_aplicaMultiplicacionPorDos() {
        assertEquals(10, Nivel.FACIL.aplicar(5));
        assertEquals(0, Nivel.FACIL.aplicar(0));
        assertEquals(-6, Nivel.FACIL.aplicar(-3));
    }

    @Test
    void intermedio_aplicaSumaDeCinco() {
        assertEquals(15, Nivel.INTERMEDIO.aplicar(10));
        assertEquals(5, Nivel.INTERMEDIO.aplicar(0));
        assertEquals(2, Nivel.INTERMEDIO.aplicar(-3));
    }

    @Test
    void dificil_aplicaMultiplicacionPorTres() {
        assertEquals(15, Nivel.DIFICIL.aplicar(5));
        assertEquals(0, Nivel.DIFICIL.aplicar(0));
        assertEquals(-9, Nivel.DIFICIL.aplicar(-3));
    }

    @Test
    void getExpresion_retornaTextoCorrectoPorNivel() {
        assertEquals("x*2", Nivel.FACIL.getExpresion());
        assertEquals("x+5", Nivel.INTERMEDIO.getExpresion());
        assertEquals("x*3", Nivel.DIFICIL.getExpresion());
    }

    @Test
    void verificarExpresion_aceptaTextoExacto() {
        assertTrue(Nivel.FACIL.verificarExpresion("x*2"));
        assertTrue(Nivel.INTERMEDIO.verificarExpresion("x+5"));
        assertTrue(Nivel.DIFICIL.verificarExpresion("x*3"));
    }

    @Test
    void verificarExpresion_aceptaConEspacios() {
        assertTrue(Nivel.FACIL.verificarExpresion("x * 2"));
        assertTrue(Nivel.INTERMEDIO.verificarExpresion("x + 5"));
    }

    @Test
    void verificarExpresion_rechazaTextoIncorrecto() {
        assertFalse(Nivel.FACIL.verificarExpresion("x*3"));
        assertFalse(Nivel.INTERMEDIO.verificarExpresion("x*2"));
        assertFalse(Nivel.DIFICIL.verificarExpresion("x+5"));
    }

    @Test
    void verificarExpresion_rechazaNullYVacio() {
        assertFalse(Nivel.FACIL.verificarExpresion(null));
        assertFalse(Nivel.FACIL.verificarExpresion(""));
        assertFalse(Nivel.FACIL.verificarExpresion("   "));
    }
}
