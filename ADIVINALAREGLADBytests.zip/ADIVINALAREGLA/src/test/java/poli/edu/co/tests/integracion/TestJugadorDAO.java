package poli.edu.co.tests.integracion;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import poli.edu.co.modelo.Jugador;
import poli.edu.co.modelo.dao.JugadorDAOImpl;

import java.util.List;

/**
 * Tests de integración para JugadorDAOImpl.
 *
 * Requieren que MySQL (XAMPP) esté ejecutándose y que la base de datos
 * "adivina_regla" exista con la tabla jugadores.
 */
public class TestJugadorDAO {

    private final JugadorDAOImpl dao = new JugadorDAOImpl();

    @Test
    void guardar_asignaIdGenerado() {
        Jugador jugador = new Jugador("TestJugador", 700, "FACIL");

        dao.guardar(jugador);

        assertTrue(jugador.getId() > 0,
                "El id debe ser mayor a 0 tras el guardado");
    }

    @Test
    void guardar_almacenaNombreYPuntaje() {
        Jugador jugador = new Jugador("JugadorTest2", 400, "INTERMEDIO");

        dao.guardar(jugador);

        List<Jugador> lista = dao.obtenerTop10();
        assertNotNull(lista);

        boolean encontrado = lista.stream()
                .anyMatch(j -> j.getNombre().equals("JugadorTest2"));

        assertTrue(encontrado,
                "El jugador guardado debe aparecer en la lista");
    }

    @Test
    void obtenerTop10_noRetornaNull() {
        List<Jugador> lista = dao.obtenerTop10();
        assertNotNull(lista);
    }

    @Test
    void obtenerTop10_retornaMaximoDiezRegistros() {
        List<Jugador> lista = dao.obtenerTop10();

        assertTrue(lista.size() <= 10,
                "La lista no puede tener más de 10 elementos");
    }

    @Test
    void obtenerTop10_objetosBienFormados() {
        dao.guardar(new Jugador("Control", 100, "DIFICIL"));

        List<Jugador> lista = dao.obtenerTop10();

        if (!lista.isEmpty()) {
            Jugador j = lista.get(0);

            assertNotNull(j.getNombre(),
                    "El nombre no debe ser null");

            assertTrue(j.getPuntaje() >= 0,
                    "El puntaje debe ser >= 0");

            assertTrue(j.getId() > 0,
                    "El id debe ser > 0");
        }
    }
}
