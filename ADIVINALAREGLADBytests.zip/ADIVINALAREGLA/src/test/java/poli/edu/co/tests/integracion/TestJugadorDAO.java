package poli.edu.co.tests.integracion;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import poli.edu.co.modelo.Jugador;
import poli.edu.co.modelo.dao.JugadorDAOImpl;

import java.util.List;

/**
 * Tests de integración para JugadorDAOImpl.
 *
 * ⚠️ Requieren que MySQL (XAMPP) esté corriendo y la BD "adivina_regla" exista.
 *    Siguiendo el mismo patrón de los tests del profesor (TestDAOTarjeta, TestDAOTitular).
 */
public class TestJugadorDAO {

    JugadorDAOImpl dao = new JugadorDAOImpl();

    // ✔️ 1. guardar() persiste el jugador y asigna un id generado
    @Test
    void guardar_asignaIdGenerado() {
        Jugador jugador = new Jugador("TestJugador", 700);

        dao.guardar(jugador);

        assertTrue(jugador.getId() > 0,
            "El id debe ser mayor a 0 tras el guardado");
    }

    // ✔️ 2. guardar() almacena nombre y puntaje correctamente
    @Test
    void guardar_almacenaNombreYPuntaje() {
        Jugador jugador = new Jugador("JugadorTest2", 400);

        dao.guardar(jugador);

        // Verificamos que quedó guardado consultando el top
        List<Jugador> lista = dao.obtenerTop10();
        assertNotNull(lista);

        boolean encontrado = lista.stream()
            .anyMatch(j -> j.getNombre().equals("JugadorTest2"));
        assertTrue(encontrado, "El jugador guardado debe aparecer en la lista");
    }

    // ✔️ 3. obtenerTop10() no retorna null
    @Test
    void obtenerTop10_noRetornaNull() {
        List<Jugador> lista = dao.obtenerTop10();
        assertNotNull(lista);
    }

    // ✔️ 4. obtenerTop10() retorna como máximo 10 registros
    @Test
    void obtenerTop10_retornaMaximoDiezRegistros() {
        List<Jugador> lista = dao.obtenerTop10();
        assertTrue(lista.size() <= 10,
            "La lista no puede tener más de 10 elementos");
    }

    // ✔️ 5. obtenerTop10() retorna objetos bien formados
    @Test
    void obtenerTop10_objetosBienFormados() {
        // Aseguramos que haya al menos un jugador
        dao.guardar(new Jugador("Control", 100));

        List<Jugador> lista = dao.obtenerTop10();

        if (!lista.isEmpty()) {
            Jugador j = lista.get(0);
            assertNotNull(j.getNombre(), "El nombre no debe ser null");
            assertTrue(j.getPuntaje() >= 0, "El puntaje debe ser >= 0");
            assertTrue(j.getId() > 0, "El id debe ser > 0");
        }
    }
}
