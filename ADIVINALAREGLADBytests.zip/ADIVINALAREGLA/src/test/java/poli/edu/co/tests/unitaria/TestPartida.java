package poli.edu.co.tests.unitaria;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import poli.edu.co.modelo.Nivel;
import poli.edu.co.modelo.Partida;

/**
 * Tests unitarios para la clase Partida.
 * No requieren base de datos ni JavaFX.
 */
public class TestPartida {

    private Partida partida;

    @BeforeEach
    void setUp() {
        // Usamos FACIL (x*2) para que los resultados sean predecibles
        partida = new Partida(Nivel.FACIL);
    }

    // ── Estado inicial ────────────────────────────────────────────────────────

    @Test
    void estadoInicial_noEstaEnModoValidacion() {
        assertFalse(partida.isModoValidacion());
    }

    @Test
    void estadoInicial_noEstaTerminada() {
        assertFalse(partida.isTerminada());
    }

    @Test
    void estadoInicial_tieneMaxIntentos() {
        assertEquals(Partida.MAX_INTENTOS, partida.getIntentosRestantes());
    }

    // ── aplicarRegla() ────────────────────────────────────────────────────────

    @Test
    void aplicarRegla_retornaResultadoCorrecto() {
        assertEquals(10, partida.aplicarRegla(5));
        assertEquals(0,  partida.aplicarRegla(0));
        assertEquals(20, partida.aplicarRegla(10));
    }

    // ── iniciarModoValidacion() ───────────────────────────────────────────────

    @Test
    void iniciarModoValidacion_cambiaModo() {
        partida.iniciarModoValidacion();
        assertTrue(partida.isModoValidacion());
    }

    @Test
    void iniciarModoValidacion_generaEntradasReto() {
        partida.iniciarModoValidacion();
        int[] entradas = partida.getEntradasReto();
        assertEquals(4, entradas.length);
        for (int entrada : entradas) {
            assertTrue(entrada >= 1 && entrada <= 9,
                "Cada entrada del reto debe estar entre 1 y 9, era: " + entrada);
        }
    }

    // ── volverExploracion() ───────────────────────────────────────────────────

    @Test
    void volverExploracion_desactivaModoValidacion() {
        partida.iniciarModoValidacion();
        partida.volverExploracion();
        assertFalse(partida.isModoValidacion());
    }

    // ── verificarExpresion() ──────────────────────────────────────────────────

    @Test
    void verificarExpresion_aceptaExpresionCorrecta() {
        assertTrue(partida.verificarExpresion("x*2"));
    }

    @Test
    void verificarExpresion_rechazaExpresionIncorrecta() {
        assertFalse(partida.verificarExpresion("x+5"));
        assertFalse(partida.verificarExpresion("x*3"));
    }

    // ── registrarIntentoFallido() ─────────────────────────────────────────────

    @Test
    void registrarIntentoFallido_decrementaIntentos() {
        partida.registrarIntentoFallido();
        assertEquals(Partida.MAX_INTENTOS - 1, partida.getIntentosRestantes());
    }

    @Test
    void registrarIntentoFallido_retornaTrueAlAgotar() {
        // Agotar todos los intentos
        for (int i = 0; i < Partida.MAX_INTENTOS - 1; i++) {
            assertFalse(partida.registrarIntentoFallido());
        }
        assertTrue(partida.registrarIntentoFallido());
        assertTrue(partida.isTerminada());
    }

    // ── ganar() ───────────────────────────────────────────────────────────────

    @Test
    void ganar_marcaPartidaComoTerminadaYGanada() {
        partida.ganar();
        assertTrue(partida.isTerminada());
        assertTrue(partida.isGanada());
    }

    // ── getExpresionRegla() ───────────────────────────────────────────────────

    @Test
    void getExpresionRegla_retornaExpresionDelNivel() {
        assertEquals("x*2", partida.getExpresionRegla());
    }
}
