package poli.edu.co.tests.unitaria;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import poli.edu.co.modelo.Nivel;
import poli.edu.co.modelo.Partida;
import poli.edu.co.modelo.Regla;
import poli.edu.co.modelo.Jugador;
import poli.edu.co.modelo.dao.JugadorDAO;

/**
 * Tests unitarios para la clase Partida.
 */
public class TestPartida {

    private Partida partida;

    @BeforeEach
    void setUp() {

        // Implementación anónima del DAO (stub)
        JugadorDAO daoStub = new JugadorDAO() {
            @Override
            public void guardar(Jugador jugador) {
                // No hace nada
            }

            @Override
            public List<Jugador> obtenerTop10() {
                return new ArrayList<>();
            }
        };

        partida = new Partida(daoStub);
        partida.iniciarConNivel(Nivel.FACIL, new Regla(Nivel.FACIL));
    }

    // ── Estado inicial ────────────────────────────────────────────────────────

    @Test
    void estadoInicial_noEstaEnModoValidacion() {
        assertFalse(partida.isModoValidacion());
    }

    @Test
    void estadoInicial_noEstaTerminada() {
        assertFalse(partida.isTerminada());
    }

    @Test
    void estadoInicial_tieneMaxIntentos() {
        assertEquals(Partida.MAX_INTENTOS, partida.getIntentosRestantes());
    }

    // ── aplicarRegla() ────────────────────────────────────────────────────────

    @Test
    void aplicarRegla_retornaResultadoCorrecto() {
        assertEquals(10, partida.aplicarRegla(5));
        assertEquals(0, partida.aplicarRegla(0));
        assertEquals(20, partida.aplicarRegla(10));
    }

    // ── iniciarModoValidacion() ───────────────────────────────────────────────

    @Test
    void iniciarModoValidacion_cambiaModo() {
        partida.iniciarModoValidacion();
        assertTrue(partida.isModoValidacion());
    }

    @Test
    void iniciarModoValidacion_generaEntradasReto() {
        partida.iniciarModoValidacion();

        int[] entradas = partida.getEntradasReto();

        assertEquals(4, entradas.length);

        for (int entrada : entradas) {
            assertTrue(entrada >= 1 && entrada <= 9);
        }
    }

    // ── volverExploracion() ───────────────────────────────────────────────────

    @Test
    void volverExploracion_desactivaModoValidacion() {
        partida.iniciarModoValidacion();
        partida.volverExploracion();

        assertFalse(partida.isModoValidacion());
    }

    // ── verificarExpresion() ──────────────────────────────────────────────────

    @Test
    void verificarExpresion_aceptaExpresionCorrecta() {
        assertTrue(partida.verificarExpresion("x*2"));
    }

    @Test
    void verificarExpresion_rechazaExpresionIncorrecta() {
        assertFalse(partida.verificarExpresion("x+5"));
        assertFalse(partida.verificarExpresion("x*3"));
    }

    // ── registrarIntentoFallido() ─────────────────────────────────────────────

    @Test
    void registrarIntentoFallido_decrementaIntentos() {
        partida.registrarIntentoFallido();

        assertEquals(
                Partida.MAX_INTENTOS - 1,
                partida.getIntentosRestantes()
        );
    }

    @Test
    void registrarIntentoFallido_retornaTrueAlAgotar() {
        for (int i = 0; i < Partida.MAX_INTENTOS - 1; i++) {
            assertFalse(partida.registrarIntentoFallido());
        }

        assertTrue(partida.registrarIntentoFallido());
        assertTrue(partida.isTerminada());
    }

    // ── ganar() ───────────────────────────────────────────────────────────────

    @Test
    void ganar_marcaPartidaComoTerminadaYGanada() {
        partida.ganar();

        assertTrue(partida.isTerminada());
        assertTrue(partida.isGanada());
    }

    // ── getExpresionRegla() ───────────────────────────────────────────────────

    @Test
    void getExpresionRegla_retornaExpresionDelNivel() {
        assertEquals("x*2", partida.getExpresionRegla());
    }
}
