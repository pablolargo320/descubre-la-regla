package poli.edu.co.tests.unitaria;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import poli.edu.co.modelo.Partida;
import poli.edu.co.modelo.Puntaje;

/**
 * Tests unitarios para la clase Puntaje.
 * No requieren base de datos ni JavaFX.
 */
public class TestPuntaje {

    // ── cero() ────────────────────────────────────────────────────────────────

    @Test
    void cero_retornaValorCero() {
        assertEquals(0, Puntaje.cero().getValor());
    }

    // ── calcular() — victoria ─────────────────────────────────────────────────

    @Test
    void calcular_victoriaConCeroFallos_retornaPuntajeMaximo() {
        Puntaje p = Puntaje.calcular(Partida.MAX_INTENTOS, true);
        assertEquals(1000, p.getValor());
    }

    @Test
    void calcular_victoriaConUnFallo_descuentaTrescientos() {
        Puntaje p = Puntaje.calcular(Partida.MAX_INTENTOS - 1, true);
        assertEquals(700, p.getValor());
    }

    @Test
    void calcular_victoriaConDosFallos_descuentaSeisCientos() {
        Puntaje p = Puntaje.calcular(Partida.MAX_INTENTOS - 2, true);
        assertEquals(400, p.getValor());
    }

    // ── calcular() — derrota ──────────────────────────────────────────────────

    @Test
    void calcular_derrotaSiempreRetornaCero() {
        assertEquals(0, Puntaje.calcular(Partida.MAX_INTENTOS, false).getValor());
        assertEquals(0, Puntaje.calcular(0, false).getValor());
    }

    // ── toString() ────────────────────────────────────────────────────────────

    @Test
    void toString_contieneElValorYLaPalabraPts() {
        String texto = Puntaje.calcular(Partida.MAX_INTENTOS, true).toString();
        assertTrue(texto.contains("1000"));
        assertTrue(texto.contains("pts"));
    }
}
