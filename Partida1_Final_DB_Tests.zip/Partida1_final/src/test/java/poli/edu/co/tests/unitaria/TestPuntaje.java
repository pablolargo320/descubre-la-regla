package poli.edu.co.tests.unitaria;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import poli.edu.co.modelo.Partida;
import poli.edu.co.modelo.Puntaje;

/**
 * Tests unitarios para la clase Puntaje.
 *
 * <p>Fórmula: 1000 - (intentos_fallidos × 300).
 * No requieren base de datos ni JavaFX.</p>
 */
public class TestPuntaje {

    // ── cero() ────────────────────────────────────────────────────────────────

    @Test
    void cero_retornaValorCero() {
        assertEquals(0, Puntaje.cero().getValor());
    }

    // ── calcular() — victoria ─────────────────────────────────────────────────

    @Test
    void calcular_victoriaConCeroFallos_retornaPuntajeMaximo() {
        // Todos los intentos restantes → 0 fallos → 1000 pts
        Puntaje p = Puntaje.calcular(Partida.MAX_INTENTOS, true);
        assertEquals(1000, p.getValor());
    }

    @Test
    void calcular_victoriaConUnFallo_descuentaTrescientos() {
        // 1 fallo → 1000 - 300 = 700 pts
        Puntaje p = Puntaje.calcular(Partida.MAX_INTENTOS - 1, true);
        assertEquals(700, p.getValor());
    }

    @Test
    void calcular_victoriaConDosFallos_descuentaSeisCientos() {
        // 2 fallos → 1000 - 600 = 400 pts
        Puntaje p = Puntaje.calcular(Partida.MAX_INTENTOS - 2, true);
        assertEquals(400, p.getValor());
    }

    // ── calcular() — derrota ──────────────────────────────────────────────────

    @Test
    void calcular_derrotaSiempreRetornaCero() {
        assertEquals(0, Puntaje.calcular(Partida.MAX_INTENTOS, false).getValor());
        assertEquals(0, Puntaje.calcular(0, false).getValor());
    }

    // ── toString() ────────────────────────────────────────────────────────────

    @Test
    void toString_contieneElValorYLaPalabraPts() {
        String texto = Puntaje.calcular(Partida.MAX_INTENTOS, true).toString();
        assertTrue(texto.contains("1000"));
        assertTrue(texto.contains("pts"));
    }
}
