package poli.edu.co.tests.unitaria;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import poli.edu.co.modelo.Nivel;

/**
 * Tests unitarios para el enum Nivel.
 *
 * <p>Reglas actuales del juego:
 * <ul>
 *   <li>FACIL      → x * 2        (expresión: "x * 2")</li>
 *   <li>INTERMEDIO → x * 2 + 5    (expresión: "x * 2 + 5")</li>
 *   <li>DIFICIL    → x² + 10      (expresión: "x^2 + 10")</li>
 * </ul>
 *
 * No requieren base de datos ni JavaFX.</p>
 */
public class TestNivel {

    // ── aplicar() ─────────────────────────────────────────────────────────────

    @Test
    void facil_aplicaMultiplicacionPorDos() {
        assertEquals(10,  Nivel.FACIL.aplicar(5));
        assertEquals(0,   Nivel.FACIL.aplicar(0));
        assertEquals(-6,  Nivel.FACIL.aplicar(-3));
    }

    @Test
    void intermedio_aplicaDobleDeXMasCinco() {
        // Regla: x * 2 + 5
        assertEquals(25, Nivel.INTERMEDIO.aplicar(10));  // 10*2+5 = 25
        assertEquals(5,  Nivel.INTERMEDIO.aplicar(0));   //  0*2+5 =  5
        assertEquals(-1, Nivel.INTERMEDIO.aplicar(-3));  // -3*2+5 = -1
    }

    @Test
    void dificil_aplicaCuadradoMasDiez() {
        // Regla: x^2 + 10
        assertEquals(35, Nivel.DIFICIL.aplicar(5));   // 5²+10  = 35
        assertEquals(10, Nivel.DIFICIL.aplicar(0));   // 0²+10  = 10
        assertEquals(19, Nivel.DIFICIL.aplicar(3));   // 3²+10  = 19
        assertEquals(19, Nivel.DIFICIL.aplicar(-3));  // (-3)²+10 = 19
    }

    // ── getExpresion() ────────────────────────────────────────────────────────

    @Test
    void getExpresion_retornaTextoCorrectoPorNivel() {
        assertEquals("x * 2",      Nivel.FACIL.getExpresion());
        assertEquals("x * 2 + 5",  Nivel.INTERMEDIO.getExpresion());
        assertEquals("x^2 + 10",   Nivel.DIFICIL.getExpresion());
    }
}
