package poli.edu.co.tests.integracion;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import poli.edu.co.modelo.Jugador;
import poli.edu.co.modelo.dao.JugadorDAOImpl;

import java.util.List;

/**
 * Tests de integración para JugadorDAOImpl.
 *
 * <p><strong>⚠️ Requieren que MySQL (XAMPP) esté corriendo</strong>
 * y que la base de datos {@code adivina_regla} exista con la tabla
 * {@code jugadores} (columnas: id, nombre, puntaje, dificultad, fecha).
 *
 * <p>Si MySQL no está activo, estos tests fallarán con un RuntimeException
 * descriptivo — ese es el comportamiento esperado.</p>
 */
public class TestJugadorDAO {

    JugadorDAOImpl dao = new JugadorDAOImpl();

    // ── guardar() ─────────────────────────────────────────────────────────────

    /**
     * Verifica que guardar() persiste el jugador y asigna el id generado por MySQL.
     */
    @Test
    void guardar_asignaIdGenerado() {
        // Jugador ahora requiere 3 parámetros: nombre, puntaje, dificultad
        Jugador jugador = new Jugador("TestJugador", 700, "FACIL");

        dao.guardar(jugador);

        assertTrue(jugador.getId() > 0,
            "El id debe ser mayor a 0 tras el guardado en MySQL");
    }

    /**
     * Verifica que guardar() almacena correctamente nombre, puntaje y dificultad.
     */
    @Test
    void guardar_almacenaNombrePuntajeYDificultad() {
        Jugador jugador = new Jugador("JugadorTest2", 400, "INTERMEDIO");

        dao.guardar(jugador);

        List<Jugador> lista = dao.obtenerTop10();
        assertNotNull(lista);

        boolean encontrado = lista.stream()
            .anyMatch(j -> j.getNombre().equals("JugadorTest2")
                       && j.getDificultad().equals("INTERMEDIO"));

        assertTrue(encontrado,
            "El jugador guardado debe aparecer en el top con su dificultad");
    }

    // ── obtenerTop10() ────────────────────────────────────────────────────────

    /**
     * Verifica que obtenerTop10() nunca retorna null.
     */
    @Test
    void obtenerTop10_noRetornaNull() {
        List<Jugador> lista = dao.obtenerTop10();
        assertNotNull(lista);
    }

    /**
     * Verifica que obtenerTop10() retorna como máximo 10 registros.
     */
    @Test
    void obtenerTop10_retornaMaximoDiezRegistros() {
        List<Jugador> lista = dao.obtenerTop10();
        assertTrue(lista.size() <= 10,
            "La lista no puede tener más de 10 elementos");
    }

    /**
     * Verifica que los objetos retornados por obtenerTop10() están bien formados
     * (nombre no null, puntaje >= 0, id > 0, dificultad no null ni vacía).
     */
    @Test
    void obtenerTop10_objetosBienFormados() {
        dao.guardar(new Jugador("Control", 100, "DIFICIL"));

        List<Jugador> lista = dao.obtenerTop10();

        if (!lista.isEmpty()) {
            Jugador j = lista.get(0);
            assertNotNull(j.getNombre(),      "El nombre no debe ser null");
            assertNotNull(j.getDificultad(),  "La dificultad no debe ser null");
            assertFalse(j.getDificultad().isBlank(), "La dificultad no debe estar vacía");
            assertTrue(j.getPuntaje() >= 0,  "El puntaje debe ser >= 0");
            assertTrue(j.getId() > 0,        "El id debe ser > 0");
        }
    }

    // ── obtenerTop10PorDificultad() ───────────────────────────────────────────

    /**
     * Verifica que obtenerTop10PorDificultad() nunca retorna null.
     */
    @Test
    void obtenerTop10PorDificultad_noRetornaNull() {
        List<Jugador> lista = dao.obtenerTop10PorDificultad("FACIL");
        assertNotNull(lista);
    }

    /**
     * Verifica que todos los resultados tienen la dificultad solicitada.
     */
    @Test
    void obtenerTop10PorDificultad_soloRetornaDificultadFiltrada() {
        // Asegurar que haya al menos un registro DIFICIL
        dao.guardar(new Jugador("FiltroTest", 999, "DIFICIL"));

        List<Jugador> lista = dao.obtenerTop10PorDificultad("DIFICIL");

        assertNotNull(lista);
        for (Jugador j : lista) {
            assertEquals("DIFICIL", j.getDificultad(),
                "Todos los registros deben ser de dificultad DIFICIL");
        }
    }

    /**
     * Verifica que el filtro por dificultad retorna máximo 10 registros.
     */
    @Test
    void obtenerTop10PorDificultad_retornaMaximoDiezRegistros() {
        List<Jugador> lista = dao.obtenerTop10PorDificultad("INTERMEDIO");
        assertTrue(lista.size() <= 10,
            "El filtro por dificultad no puede retornar más de 10 registros");
    }
}
