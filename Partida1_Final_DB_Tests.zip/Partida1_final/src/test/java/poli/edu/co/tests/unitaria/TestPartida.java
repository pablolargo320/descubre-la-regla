package poli.edu.co.tests.unitaria;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import poli.edu.co.modelo.Jugador;
import poli.edu.co.modelo.Nivel;
import poli.edu.co.modelo.Partida;
import poli.edu.co.modelo.Regla;
import poli.edu.co.modelo.dao.JugadorDAO;

import java.util.ArrayList;
import java.util.List;

/**
 * Tests unitarios para la clase Partida.
 *
 * <p>Usa un DAO falso (stub en memoria) para que los tests no necesiten
 * MySQL ni XAMPP activo. Todos los niveles usan FACIL (x*2) para que
 * los resultados sean predecibles.</p>
 */
public class TestPartida {

    // ── DAO stub (en memoria, sin base de datos) ──────────────────────────────

    /**
     * Implementación mínima de JugadorDAO que guarda en una lista en memoria.
     * Evita que los tests unitarios dependan de MySQL.
     */
    private static class JugadorDAOStub implements JugadorDAO {
        private final List<Jugador> guardados = new ArrayList<>();
        private int nextId = 1;

        @Override
        public void guardar(Jugador jugador) {
            jugador.setId(nextId++);
            guardados.add(jugador);
        }

        @Override
        public List<Jugador> obtenerTop10() {
            return new ArrayList<>(guardados);
        }

        @Override
        public List<Jugador> obtenerTop10PorDificultad(String dificultad) {
            return guardados.stream()
                .filter(j -> j.getDificultad().equals(dificultad))
                .toList();
        }

        public List<Jugador> getGuardados() { return guardados; }
    }

    // ── Fixtures ──────────────────────────────────────────────────────────────

    private Partida          partida;
    private JugadorDAOStub   daoStub;

    @BeforeEach
    void setUp() {
        daoStub = new JugadorDAOStub();
        partida = new Partida(daoStub);
        // Iniciamos con FACIL (x*2) para que los resultados sean predecibles
        partida.iniciarConNivel(Nivel.FACIL, new Regla(Nivel.FACIL));
    }

    // ── Estado inicial ────────────────────────────────────────────────────────

    @Test
    void estadoInicial_noEstaEnModoValidacion() {
        assertFalse(partida.isModoValidacion());
    }

    @Test
    void estadoInicial_noEstaTerminada() {
        assertFalse(partida.isTerminada());
    }

    @Test
    void estadoInicial_tieneMaxIntentos() {
        assertEquals(Partida.MAX_INTENTOS, partida.getIntentosRestantes());
    }

    // ── aplicarRegla() ────────────────────────────────────────────────────────

    @Test
    void aplicarRegla_retornaResultadoCorrecto() {
        // FACIL: x * 2
        assertEquals(10, partida.aplicarRegla(5));
        assertEquals(0,  partida.aplicarRegla(0));
        assertEquals(20, partida.aplicarRegla(10));
    }

    // ── iniciarModoValidacion() ───────────────────────────────────────────────

    @Test
    void iniciarModoValidacion_cambiaModo() {
        partida.iniciarModoValidacion();
        assertTrue(partida.isModoValidacion());
    }

    @Test
    void iniciarModoValidacion_generaEntradasReto() {
        partida.iniciarModoValidacion();
        int[] entradas = partida.getEntradasReto();
        assertEquals(4, entradas.length);
        for (int entrada : entradas) {
            assertTrue(entrada >= 1 && entrada <= 9,
                "Cada entrada del reto debe estar entre 1 y 9, era: " + entrada);
        }
    }

    // ── volverExploracion() ───────────────────────────────────────────────────

    @Test
    void volverExploracion_desactivaModoValidacion() {
        partida.iniciarModoValidacion();
        partida.volverExploracion();
        assertFalse(partida.isModoValidacion());
    }

    // ── verificarExpresion() ──────────────────────────────────────────────────

    @Test
    void verificarExpresion_aceptaExpresionCorrecta() {
        // FACIL: "x * 2" (con y sin espacios)
        assertTrue(partida.verificarExpresion("x * 2"));
        assertTrue(partida.verificarExpresion("x*2"));
    }

    @Test
    void verificarExpresion_rechazaExpresionIncorrecta() {
        assertFalse(partida.verificarExpresion("x + 5"));
        assertFalse(partida.verificarExpresion("x * 3"));
        assertFalse(partida.verificarExpresion("x^2 + 10"));
    }

    // ── registrarIntentoFallido() ─────────────────────────────────────────────

    @Test
    void registrarIntentoFallido_decrementaIntentos() {
        partida.registrarIntentoFallido();
        assertEquals(Partida.MAX_INTENTOS - 1, partida.getIntentosRestantes());
    }

    @Test
    void registrarIntentoFallido_retornaTrueAlAgotar() {
        // Agotar todos los intentos menos el último → false
        for (int i = 0; i < Partida.MAX_INTENTOS - 1; i++) {
            assertFalse(partida.registrarIntentoFallido(),
                "Aún no deben agotarse los intentos en el intento " + (i + 1));
        }
        // Último intento → true (perdió)
        assertTrue(partida.registrarIntentoFallido());
        assertTrue(partida.isTerminada());
    }

    // ── ganar() ───────────────────────────────────────────────────────────────

    @Test
    void ganar_marcaPartidaComoTerminadaYGanada() {
        partida.ganar();
        assertTrue(partida.isTerminada());
        assertTrue(partida.isGanada());
    }

    // ── getExpresionRegla() ───────────────────────────────────────────────────

    @Test
    void getExpresionRegla_retornaExpresionDelNivel() {
        assertEquals("x * 2", partida.getExpresionRegla());
    }

    // ── guardarJugador() ──────────────────────────────────────────────────────

    @Test
    void guardarJugador_persisteConTresCampos() {
        partida.ganar();
        Jugador jugador = new Jugador("Ana", partida.getPuntaje().getValor(), "FACIL");
        partida.guardarJugador(jugador);

        assertTrue(jugador.getId() > 0, "El stub debe asignar un id > 0");
        assertEquals(1, daoStub.getGuardados().size());
        assertEquals("Ana",   daoStub.getGuardados().get(0).getNombre());
        assertEquals("FACIL", daoStub.getGuardados().get(0).getDificultad());
    }

    @Test
    void guardarJugador_conJugadorNulo_lanzaExcepcion() {
        assertThrows(IllegalArgumentException.class,
            () -> partida.guardarJugador(null));
    }
}
