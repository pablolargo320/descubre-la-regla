package poli.edu.co.controlador;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import poli.edu.co.modelo.Jugador;
import poli.edu.co.modelo.Partida;
import poli.edu.co.vista.App;

import java.io.IOException;
import java.util.List;

/**
 * Controlador de la pantalla de resultado (Resultado.fxml).
 *
 * <p>Muestra el resultado final, permite guardar nombre + puntaje + dificultad
 * en MySQL, y presenta la tabla Top-10 filtrada por la dificultad jugada.</p>
 */
public class ResultadoControlador {

    // ── Vista — resultado ─────────────────────────────────────────────────────
    @FXML private Label     resultadoLabel;
    @FXML private Label     nivelLabel;
    @FXML private Label     puntajeLabel;

    // ── Vista — registro ──────────────────────────────────────────────────────
    @FXML private TextField nombreField;
    @FXML private Label     errorNombreLabel;
    @FXML private Button    btnGuardar;
    @FXML private Label     confirmacionLabel;

    // ── Vista — tabla Top-10 ──────────────────────────────────────────────────
    @FXML private Label                         labelTituloTabla;
    @FXML private TableView<Jugador>            tablaTop;
    @FXML private TableColumn<Jugador, Integer> colPos;
    @FXML private TableColumn<Jugador, String>  colNombre;
    @FXML private TableColumn<Jugador, Integer> colPuntaje;
    @FXML private TableColumn<Jugador, String>  colDificultad;

    // ── Modelo ────────────────────────────────────────────────────────────────
    private Partida partida;

    // ── Inicialización ────────────────────────────────────────────────────────

    @FXML
    private void initialize() {
        partida = App.getPartida();
        mostrarResultado();
        configurarTabla();
        actualizarTituloTabla();
        cargarTop10();
    }

    // ── Sincronización de vista ───────────────────────────────────────────────

    private void mostrarResultado() {
        boolean gano = partida.isGanada();

        if (gano) {
            resultadoLabel.setText("¡GANASTE!");
            resultadoLabel.setStyle(
                "-fx-text-fill: #3fb950; -fx-font-size: 30px; -fx-font-weight: bold;"
                + "-fx-font-family: 'Impact', 'Arial Black';");
        } else {
            resultadoLabel.setText("PERDISTE");
            resultadoLabel.setStyle(
                "-fx-text-fill: #f85149; -fx-font-size: 30px; -fx-font-weight: bold;"
                + "-fx-font-family: 'Impact', 'Arial Black';");
        }

        nivelLabel.setText("Nivel jugado: " + partida.getNivel().name());
        puntajeLabel.setText(partida.getPuntaje().toString());

        errorNombreLabel.setVisible(false);
        errorNombreLabel.setManaged(false);
        confirmacionLabel.setVisible(false);
        confirmacionLabel.setManaged(false);
    }

    /** Muestra en el título de la tabla la dificultad que se acaba de jugar. */
    private void actualizarTituloTabla() {
        String dificultad = partida.getNivel().name(); // FACIL / INTERMEDIO / DIFICIL
        labelTituloTabla.setText("🏆  Top 10 — " + dificultad);
    }

    /** Configura las columnas de la TableView. */
    private void configurarTabla() {
        // Columna de posición: número de fila + 1
        colPos.setCellValueFactory(new PropertyValueFactory<>("id"));
        colPos.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(Integer item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty ? null : String.valueOf(getIndex() + 1));
            }
        });

        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colPuntaje.setCellValueFactory(new PropertyValueFactory<>("puntaje"));
        colDificultad.setCellValueFactory(new PropertyValueFactory<>("dificultad"));

        tablaTop.setPlaceholder(new Label("Aún no hay puntajes para esta dificultad."));
    }

    /**
     * Consulta el Top-10 filtrado por la dificultad que se acaba de jugar
     * y lo muestra en la tabla.
     */
    private void cargarTop10() {
        try {
            String dificultad = partida.getNivel().name();
            List<Jugador> top = App.getJugadorDAO().obtenerTop10PorDificultad(dificultad);
            ObservableList<Jugador> datos = FXCollections.observableArrayList(top);
            tablaTop.setItems(datos);
        } catch (RuntimeException e) {
            tablaTop.setPlaceholder(new Label("No se pudo cargar la tabla (¿MySQL activo?)."));
        }
    }

    // ── Eventos ───────────────────────────────────────────────────────────────

    /**
     * Valida el nombre, crea el Jugador con nombre + puntaje + dificultad
     * y lo persiste a través del modelo. Recarga el Top-10 tras guardar.
     */
    @FXML
    private void guardar() {
        String nombre = nombreField.getText().trim();

        if (nombre.isBlank()) {
            mostrarError("Debe ingresar un nombre.");
            return;
        }

        ocultarError();

        try {
            Jugador jugador = new Jugador(
                nombre,
                partida.getPuntaje().getValor(),
                partida.getNivel().name()
            );
            partida.guardarJugador(jugador);

            confirmacionLabel.setVisible(true);
            confirmacionLabel.setManaged(true);
            btnGuardar.setDisable(true);
            nombreField.setDisable(true);

            // Recargar tabla para incluir el puntaje recién guardado
            cargarTop10();

        } catch (RuntimeException e) {
            mostrarError("Error al guardar. ¿Está MySQL activo en XAMPP?");
        }
    }

    private void mostrarError(String mensaje) {
        errorNombreLabel.setText(mensaje);
        errorNombreLabel.setVisible(true);
        errorNombreLabel.setManaged(true);
    }

    private void ocultarError() {
        errorNombreLabel.setVisible(false);
        errorNombreLabel.setManaged(false);
    }

    @FXML
    private void nuevaPartida() throws IOException {
        App.setRoot("Nivel");
    }

    @FXML
    private void volverMenu() throws IOException {
        App.setRoot("primary");
    }
}
