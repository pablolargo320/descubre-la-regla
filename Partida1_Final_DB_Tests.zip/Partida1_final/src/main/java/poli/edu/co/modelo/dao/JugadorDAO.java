package poli.edu.co.modelo.dao;

import poli.edu.co.modelo.Jugador;
import java.util.List;

/**
 * Contrato de acceso a datos para la entidad Jugador.
 *
 * <p>Siguiendo el principio de Inversión de Dependencias (DIP),
 * el resto del código depende de esta interfaz y no de su implementación
 * concreta.</p>
 */
public interface JugadorDAO {

    /**
     * Persiste un jugador y rellena su id con el valor generado.
     *
     * @param jugador entidad a guardar; no debe ser null.
     */
    void guardar(Jugador jugador);

    /**
     * Devuelve los 10 mejores puntajes globales en orden descendente.
     *
     * @return lista con hasta 10 jugadores; nunca null.
     */
    List<Jugador> obtenerTop10();

    /**
     * Devuelve los 10 mejores puntajes filtrados por dificultad.
     *
     * @param dificultad FACIL, INTERMEDIO o DIFICIL.
     * @return lista con hasta 10 jugadores; nunca null.
     */
    List<Jugador> obtenerTop10PorDificultad(String dificultad);
}
