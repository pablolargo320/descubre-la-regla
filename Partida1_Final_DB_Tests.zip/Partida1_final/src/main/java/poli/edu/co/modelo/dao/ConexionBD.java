package poli.edu.co.modelo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Gestiona la conexión con la base de datos MySQL de XAMPP.
 *
 * <p>Configuración por defecto de XAMPP:
 * Host: localhost, Puerto: 3306, BD: adivina_regla, User: root, Pass: (vacía)
 *
 * <p>Antes de ejecutar la app, crea la BD en phpMyAdmin o con:
 *   CREATE DATABASE IF NOT EXISTS adivina_regla;
 */
public final class ConexionBD {

    private static final String HOST     = "localhost";
    private static final String PORT     = "3306";
    private static final String DATABASE = "adivina_regla";
    private static final String USER     = "root";
    private static final String PASSWORD = "";  // XAMPP: vacío por defecto

    private static final String URL =
        "jdbc:mysql://" + HOST + ":" + PORT + "/" + DATABASE
        + "?useSSL=false&serverTimezone=America/Bogota&allowPublicKeyRetrieval=true";

    private ConexionBD() { }

    /**
     * Abre y retorna una nueva conexión a MySQL.
     *
     * @return conexión activa; debe cerrarse con try-with-resources.
     * @throws SQLException si no se puede establecer la conexión.
     */
    public static Connection getConexion() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    /**
     * Crea la tabla jugadores en MySQL si no existe.
     * Incluye columna dificultad para guardar el nivel elegido.
     */
    public static void inicializarTablas() {
        String sql = """
                CREATE TABLE IF NOT EXISTS jugadores (
                    id         INT          NOT NULL AUTO_INCREMENT,
                    nombre     VARCHAR(100) NOT NULL,
                    puntaje    INT          NOT NULL,
                    dificultad VARCHAR(20)  NOT NULL,
                    fecha      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                """;
        try (Connection conn = getConexion();
             Statement  stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            throw new RuntimeException(
                "Error al inicializar MySQL: " + e.getMessage(), e);
        }
    }
}
