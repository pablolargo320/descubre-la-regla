package poli.edu.co.modelo.dao;

import poli.edu.co.modelo.Jugador;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementación MySQL de JugadorDAO.
 *
 * <p>Guarda nombre, puntaje y dificultad en la tabla jugadores.
 * Cada operación abre su propia conexión (connection-per-use).</p>
 */
public class JugadorDAOImpl implements JugadorDAO {

    /**
     * Persiste un jugador (nombre, puntaje, dificultad) en MySQL.
     */
    @Override
    public void guardar(Jugador jugador) {
        String sql = """
                INSERT INTO jugadores (nombre, puntaje, dificultad, fecha)
                VALUES (?, ?, ?, NOW())
                """;
        try (Connection       conn = ConexionBD.getConexion();
             PreparedStatement ps   = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, jugador.getNombre());
            ps.setInt   (2, jugador.getPuntaje());
            ps.setString(3, jugador.getDificultad());
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) jugador.setId(keys.getInt(1));
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error al guardar el jugador: " + e.getMessage(), e);
        }
    }

    /**
     * Retorna los 10 mejores puntajes globales en orden descendente.
     */
    @Override
    public List<Jugador> obtenerTop10() {
        String sql = """
                SELECT id, nombre, puntaje, dificultad
                FROM jugadores
                ORDER BY puntaje DESC
                LIMIT 10
                """;
        return ejecutarConsulta(sql, null);
    }

    /**
     * Retorna los 10 mejores puntajes de una dificultad específica.
     *
     * @param dificultad FACIL, INTERMEDIO o DIFICIL.
     */
    @Override
    public List<Jugador> obtenerTop10PorDificultad(String dificultad) {
        String sql = """
                SELECT id, nombre, puntaje, dificultad
                FROM jugadores
                WHERE dificultad = ?
                ORDER BY puntaje DESC
                LIMIT 10
                """;
        return ejecutarConsulta(sql, dificultad);
    }

    /**
     * Método auxiliar que ejecuta una consulta SELECT y mapea los resultados.
     *
     * @param sql        consulta con 0 o 1 parámetro opcional.
     * @param dificultad valor del parámetro; null si la consulta no tiene WHERE.
     */
    private List<Jugador> ejecutarConsulta(String sql, String dificultad) {
        List<Jugador> lista = new ArrayList<>();

        try (Connection conn = ConexionBD.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            if (dificultad != null) {
                ps.setString(1, dificultad);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Jugador j = new Jugador(
                        rs.getString("nombre"),
                        rs.getInt   ("puntaje"),
                        rs.getString("dificultad")
                    );
                    j.setId(rs.getInt("id"));
                    lista.add(j);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error al consultar jugadores: " + e.getMessage(), e);
        }
        return lista;
    }
}
