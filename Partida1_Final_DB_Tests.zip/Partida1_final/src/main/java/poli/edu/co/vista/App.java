package poli.edu.co.vista;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import poli.edu.co.modelo.Partida;
import poli.edu.co.modelo.dao.ConexionBD;
import poli.edu.co.modelo.dao.JugadorDAO;
import poli.edu.co.modelo.dao.JugadorDAOImpl;

import java.io.IOException;
import java.util.logging.Logger;

/**
 * Punto de entrada JavaFX — raíz de composición.
 *
 * <p>Inicializa MySQL, crea el DAO y la Partida compartida,
 * y provee navegación entre pantallas.</p>
 */
public class App extends Application {

    private static final Logger LOG = Logger.getLogger(App.class.getName());

    private static Partida    partida;
    private static JugadorDAO jugadorDAO;   // expuesto para ResultadoControlador
    private static Scene      scene;

    @Override
    public void start(Stage stage) throws IOException {
        try {
            ConexionBD.inicializarTablas();
        } catch (RuntimeException e) {
            LOG.warning("MySQL no disponible: " + e.getMessage());
        }

        jugadorDAO = new JugadorDAOImpl();
        partida    = new Partida(jugadorDAO);

        scene = new Scene(loadFXML("primary"), 660, 560);
        scene.getStylesheets().add(
            App.class.getResource("/poli/edu/co/game-style.css").toExternalForm());

        stage.setTitle("Adivina la Regla");
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }

    /** Retorna la partida compartida entre todos los controladores. */
    public static Partida getPartida() { return partida; }

    /** Retorna el DAO para que ResultadoControlador pueda cargar el Top-10. */
    public static JugadorDAO getJugadorDAO() { return jugadorDAO; }

    /**
     * Navega a otra pantalla reemplazando la raíz de la escena.
     *
     * @param fxml nombre del archivo FXML (sin extensión).
     */
    public static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader loader = new FXMLLoader(
            App.class.getResource("/poli/edu/co/" + fxml + ".fxml"));
        return loader.load();
    }

    public static void main(String[] args) {
        launch();
    }
}
