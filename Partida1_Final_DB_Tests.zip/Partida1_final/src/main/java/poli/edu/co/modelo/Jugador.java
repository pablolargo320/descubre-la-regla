package poli.edu.co.modelo;

import java.time.LocalDateTime;

/**
 * Entidad que representa a un jugador y su resultado en una partida.
 *
 * <p>Contiene nombre, puntaje, dificultad y fecha.
 * No tiene lógica de negocio ni acceso a base de datos.</p>
 */
public class Jugador {

    private int id;
    private final String nombre;
    private final int    puntaje;
    /** Nivel/dificultad jugado (FACIL, INTERMEDIO, DIFICIL). */
    private final String dificultad;
    private final LocalDateTime fecha;

    /**
     * Crea un Jugador con los datos de una partida terminada.
     *
     * @param nombre     nombre del jugador.
     * @param puntaje    puntos obtenidos.
     * @param dificultad nombre del nivel jugado.
     */
    public Jugador(String nombre, int puntaje, String dificultad) {
        this.nombre     = nombre;
        this.puntaje    = puntaje;
        this.dificultad = dificultad;
        this.fecha      = LocalDateTime.now();
    }

    public int              getId()          { return id; }
    public String           getNombre()      { return nombre; }
    public int              getPuntaje()     { return puntaje; }
    /** Devuelve el nivel/dificultad jugado (antes getNivel()). */
    public String           getDificultad()  { return dificultad; }
    /** Alias de compatibilidad — devuelve lo mismo que getDificultad(). */
    public String           getNivel()       { return dificultad; }
    public LocalDateTime    getFecha()       { return fecha; }
    public void             setId(int id)    { this.id = id; }

    @Override
    public String toString() {
        return nombre + " — " + puntaje + " pts [" + dificultad + "]";
    }
}
