/**
 * Módulo principal del juego "Adivina la Regla".
 *
 * <p>Requiere JavaFX para la interfaz gráfica y java.sql para la
 * persistencia con MySQL (XAMPP).</p>
 */
module poli.edu.co {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;
    requires java.sql;

    // MySQL Connector/J es un automatic module — se accede vía java.sql
    // No se requiere declarar com.mysql.cj explícitamente con --add-modules ALL-MODULE-PATH

    opens poli.edu.co.vista       to javafx.fxml, javafx.graphics;
    opens poli.edu.co.controlador to javafx.fxml;
    opens poli.edu.co.modelo      to javafx.fxml;

    exports poli.edu.co.vista;
    exports poli.edu.co.modelo;
    exports poli.edu.co.modelo.dao;
    exports poli.edu.co.controlador;
}
